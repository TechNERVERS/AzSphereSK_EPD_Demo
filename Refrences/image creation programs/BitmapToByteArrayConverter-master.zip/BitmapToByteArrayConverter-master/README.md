# Bitmap To Byte Array Converter
Windows app to convert bitmap image to byte array to use with e-ink display

This simple windows app was made to convert a bitmap image into a byte array to use with an 2.9 inch e-ink display from https://www.waveshare.com/wiki/2.9inch_e-Paper_Module

The panel has a 296x128 pixel back and white display and a SPI interface. 