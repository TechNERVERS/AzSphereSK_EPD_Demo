#pragma once

#include "mt3620_rdb.h"
#define VCNL4040_ISU MT3620_RDB_HEADER4_ISU2_I2C