#pragma once

// Define your connection string here.  The connection string is required to connect to Azure.
// #define MY_CONNECTION_STRING "HostName=iotc-xxxx....azure-devices.net;DeviceId=xxxx....;SharedAccessKey=xxxxx..."

#define MY_CONNECTION_STRING "HostName=iotc-af6384f0-6f64-48c4-9d69-29dc60197e2d.azure-devices.net;DeviceId=eb4c54ee-4653-4576-95fa-d2fc87d1466d;SharedAccessKey=FbTZdLKkpvLmyf8zFldRgQgbS4/WdF5//XsQanI5+Gw="