/**
 *  @filename   :   imagedata.h
 *  @brief      :   head file for imagedata.cpp
 */

extern const unsigned char IMAGE_DATA[];

/* FILE END */


